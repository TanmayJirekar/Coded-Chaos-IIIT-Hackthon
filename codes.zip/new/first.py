import mysql.connector
from datetime import datetime, timedelta
import requests

def connect_to_db():
    config = {
        'user': 'root',
        'password': 'urujshaikh#2403',  
        'host': 'localhost',
        'database': 'infoSphere'
    }
    
    try:
        connection = mysql.connector.connect(**config)
        print("Connection to the database was successful!")
        return connection
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

def retrieve_articles(connection):
    cursor = connection.cursor(dictionary=True)
    query = "SELECT * FROM articles"
    
    try:
        cursor.execute(query)
        articles = cursor.fetchall()
        return articles
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return []

def identify_outdated_articles(articles):
    outdated_articles = []
    
    today = datetime.now().date()  # Use date instead of datetime
    one_year_ago = today - timedelta(days=365)
    two_years_ago = today - timedelta(days=730)

    for article in articles:
        if article['last_updated_date'] < one_year_ago or article['publication_date'] < two_years_ago:
            outdated_articles.append(article)
    
    return outdated_articles

def fetch_update_recommendations(article_title):
    api_url = "https://api.openai.com/v1/chat/completions"
    api_key = "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"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    # Prepare the data for the request
    data = {
        "model": "gpt-3.5-turbo",  # Specify the model
        "messages": [
            {
                "role": "user",
                "content": f"Provide update recommendations for the article titled: '{article_title}'."
            }
        ],
        "max_tokens": 150  # Limit the length of the response
    }

    # Make the request
    response = requests.post(api_url, headers=headers, json=data)
    
    if response.status_code == 200:
        return response.json()  # Return the JSON response from the API
    else:
        print(f"API request failed with status code {response.status_code}: {response.text}")
        return None

def main():
    db_connection = connect_to_db()
    
    if db_connection:
        articles = retrieve_articles(db_connection)
        outdated_articles = identify_outdated_articles(articles)
        
        print("\nOutdated Articles:")
        for article in outdated_articles:
            print(f"ID: {article['id']}, Title: {article['title']}, Publication Date: {article['publication_date']}, Last Updated: {article['last_updated_date']}, Status: {article['status']}")
            
            # Fetch update recommendations for the outdated article
            recommendations = fetch_update_recommendations(article['title'])
            if recommendations:
                print("Update Recommendations:", recommendations['choices'][0]['message']['content'])
        
        db_connection.close()

if __name__ == "__main__":
    main()
