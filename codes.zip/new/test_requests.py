import requests

# URL of your Flask app
url = "http://127.0.0.1:5000/predict"

# Sample payload with article details
payload = {
    "title": "Sample Article",
    "content": "This article discusses various topics related to technology and innovation.",
    "publication_date": "2023-01-01",
    "last_updated_date": "2020-06-01"
}

# Send a POST request to the Flask app
response = requests.post(url, json=payload)

# Print the response from the server
if response.status_code == 200:
    print("Response from server:")
    print(response.json())
else:
    print(f"Error: {response.status_code} - {response.text}")
