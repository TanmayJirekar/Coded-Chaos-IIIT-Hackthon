import pandas as pd
import mysql.connector
import pickle
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer

def fetch_articles():
    # Connect to the MySQL database
    connection = mysql.connector.connect(user='root', password='urujshaikh#2403', host='localhost', database='infoSphere')
    cursor = connection.cursor()
    cursor.execute("SELECT content, status FROM articles")
    articles = cursor.fetchall()
    cursor.close()
    connection.close()
    return articles

def train_model():
    articles = fetch_articles()
    df = pd.DataFrame(articles, columns=['content', 'status'])
    df['label'] = df['status'].apply(lambda x: 0 if x == 'active' else 1)

    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(df['content'])
    y = df['label']

    # Train the model
    model = MultinomialNB()
    model.fit(X, y)

    # Save the model and vectorizer
    with open('model.pkl', 'wb') as model_file:
        pickle.dump(model, model_file)
    
    with open('vectorizer.pkl', 'wb') as vec_file:
        pickle.dump(vectorizer, vec_file)

# Call train_model() when you want to retrain your model
train_model()
