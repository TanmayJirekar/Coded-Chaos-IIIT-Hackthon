from flask import Flask, request, jsonify
import pickle
import requests

app = Flask(__name__)

# Load the trained model
with open('model.pkl', 'rb') as file:
    model = pickle.load(file)

# OpenAI API configuration
OPENAI_API_KEY = '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'
OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions'

def get_openai_recommendation(content):
    headers = {
        'Authorization': f'Bearer {OPENAI_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    # Create the payload for OpenAI API
    payload = {
        "model": "gpt-3.5-turbo",  # or any other model you want to use
        "messages": [
            {
                "role": "user",
                "content": f"Based on the following content, can you provide recommendations? {content}"
            }
        ],
        "max_tokens": 100  # Adjust max tokens based on how much response you want
    }
    
    response = requests.post(OPENAI_API_URL, headers=headers, json=payload)
    
    if response.status_code == 200:
        recommendation = response.json()['choices'][0]['message']['content']
        return recommendation
    else:
        return "Error fetching recommendations"

@app.route('/')
def index():
    return "Server is running!"

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    
    title = data.get('title')
    content = data.get('content')
    publication_date = data.get('publication_date')
    last_updated_date = data.get('last_updated_date')
    
    # Perform necessary preprocessing on the inputs (similar to training)
    prediction = model.predict([content])[0]
    
    status = 'outdated' if prediction == 1 else 'active'
    
    # Get recommendations from OpenAI
    recommendations = get_openai_recommendation(content)

    return jsonify({
        'status': status,
        'recommendations': recommendations
    })

if __name__ == '__main__':
    app.run(debug=True)
